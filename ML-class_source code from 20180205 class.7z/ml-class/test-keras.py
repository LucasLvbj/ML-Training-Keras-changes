import keras
from keras.datasets import mnist

print("Keras is installed!")
