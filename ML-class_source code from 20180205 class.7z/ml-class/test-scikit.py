import pandas
import numpy
import sklearn

print("Scikit is installed!")
